from flask import Blueprint, jsonify

summary_bp = Blueprint('summary', __name__)

@summary_bp.route('/', methods=['GET'])
def summary():
    return jsonify({"data": "summary data"})