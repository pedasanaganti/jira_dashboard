from flask import Blueprint, jsonify

defects_bp = Blueprint('defects', __name__)

@defects_bp.route('/', methods=['GET'])
def defects():
    return jsonify({"data": "defects data"})