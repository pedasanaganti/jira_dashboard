import mysql.connector
import os

def get_connection():
    return mysql.connector.connect(
        host='localhost',
        user='user',
        password='pass',
        database='jira_dashboard'
    )
