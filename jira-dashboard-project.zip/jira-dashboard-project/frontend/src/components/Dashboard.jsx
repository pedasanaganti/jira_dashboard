import DynamicTable from './DynamicTable'
import { useEffect, useState } from 'react'

export default function Dashboard() {
  const [data, setData] = useState([])

  useEffect(() => {
    fetch('http://localhost:5000/api/summary')
      .then(res => res.json())
      .then(json => setData(json.data))
  }, [])

  return <DynamicTable data={data} />
}
