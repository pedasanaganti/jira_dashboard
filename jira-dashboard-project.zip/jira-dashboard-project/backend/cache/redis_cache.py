import redis
import os

redis_client = redis.Redis(host='localhost', port=6379, db=0)

def get_cached(key):
    return redis_client.get(key)

def set_cached(key, value, ttl=60):
    redis_client.setex(key, ttl, value)