from flask import Flask
from routes.auth import auth_bp
from routes.summary import summary_bp
from routes.defects import defects_bp
from routes.stories import stories_bp
from flask_cors import CORS
from dotenv import load_dotenv

load_dotenv('../configs/sample.env')

app = Flask(__name__)
CORS(app)

app.register_blueprint(auth_bp, url_prefix='/auth')
app.register_blueprint(summary_bp, url_prefix='/api/summary')
app.register_blueprint(defects_bp, url_prefix='/api/defects')
app.register_blueprint(stories_bp, url_prefix='/api/stories')

if __name__ == "__main__":
    app.run(debug=True)
