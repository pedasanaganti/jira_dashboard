CREATE TABLE jira_issues (
  id INT AUTO_INCREMENT PRIMARY KEY,
  `key` VARCHAR(50),
  summary VARCHAR(255),
  status VARCHAR(50),
  severity VARCHAR(50),
  story_points INT,
  priority VARCHAR(50)
);

INSERT INTO jira_issues (`key`, summary, status, severity, story_points, priority)
VALUES ('JIRA-001', 'Sample defect', 'Open', 'Critical', NULL, 'High'),
       ('JIRA-002', 'Sample story', 'In Progress', NULL, 5, 'Medium');