from flask import Blueprint, jsonify

stories_bp = Blueprint('stories', __name__)

@stories_bp.route('/', methods=['GET'])
def stories():
    return jsonify({"data": "stories data"})
