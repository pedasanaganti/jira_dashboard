export default function DynamicTable({ data }) {
  return (
    <table>
      <thead>
        <tr><th>Data</th></tr>
      </thead>
      <tbody>
        {data && data.map((row, idx) => (
          <tr key={idx}><td>{row}</td></tr>
        ))}
      </tbody>
    </table>
  )
}